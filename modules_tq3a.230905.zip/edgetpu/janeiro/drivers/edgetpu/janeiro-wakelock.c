// SPDX-License-Identifier: GPL-2.0
#include "edgetpu-wakelock.c"
