// SPDX-License-Identifier: GPL-2.0
/*
 * Janeiro Edge TPU ML accelerator firmware download support.
 *
 * Copyright (C) 2020 Google, Inc.
 */

#include "mobile-firmware.c"
