/* SPDX-License-Identifier: GPL-2.0 */
/*
 * Copyright (C) 2019 Google LLC.
 *
 */

#ifndef _DT_BINDINGS_WC_P9221_WC_H
#define _DT_BINDINGS_WC_P9221_WC_H

#define P9221_WC_DC_RESET_VOUTCHANGED		1
#define P9221_WC_DC_RESET_MODECHANGED		2

#endif /* _DT_BINDINGS_POWER_MT7622_POWER_H */
